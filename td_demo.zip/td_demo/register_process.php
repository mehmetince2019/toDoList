<?php
// Veritabanı bağlantısı için gerekli bilgiler
$servername = "localhost";
$username = "user_xxx";
$password = "pass_xxx";
$dbname = "db_xxx";

// Veritabanına bağlanma
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol etme
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// Formdan gelen verileri alma
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];

// Kullanıcı adının kullanılmadığından emin olma
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "Bu kullanıcı adı zaten kullanılıyor.";
    exit();
}

// Yeni kullanıcıyı veritabanına ekleme
$sql = "INSERT INTO users (username, password, email) VALUES ('$username', '$password', '$email')";

if ($conn->query($sql) === TRUE) {
    echo "Üyelik başarıyla oluşturuldu.<a href=\"index.php\">Ana Sayfa'ya Geri Dön</a>";
    
	
} else {
    echo "Hata: " . $sql . "<br>" . $conn->error;
}

// Veritabanı bağlantısını kapatma
$conn->close();
?>
