<?php
error_reporting(0);

include_once 'datab.php';



if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch data from todo_done table based on the provided ID
    $fetch_query = "SELECT * FROM todo_spaeter WHERE id = $id";
    $result = mysqli_query($baglan, $fetch_query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        // Insert data into todo table
        $insert_query = "INSERT INTO todo (id, thema, message) VALUES (
            '{$row['id']}',
            '{$row['thema']}',
            '{$row['message']}'
        )";

        $insert_result = mysqli_query($baglan, $insert_query);

        if ($insert_result) {
            // Optionally, delete the entry from todo_done table
            $delete_query = "DELETE FROM todo_spaeter WHERE id = $id";
            mysqli_query($baglan, $delete_query);

            echo "Task sent back successfully.";
            header("Location: spaeter.php");
            exit();
        } else {
            echo "Error sending task back to todo table: " . mysqli_error($baglan);
        }
    } else {
        echo "Error fetching data from todo_done table: " . mysqli_error($baglan);
    }
} else {
    echo "Invalid request. Missing or empty 'id' parameter.";
}
?>
