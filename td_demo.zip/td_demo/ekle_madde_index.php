<?php
// include database connection file
include_once("datab.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $thema = $_POST['thema'];
    $message = $_POST['message'];

    $sql = "INSERT INTO todo (thema, message) VALUES ('$thema', '$message')";

    if (mysqli_query($baglan, $sql)) {
        // Ekleme işlemi başarılı olduğunda kullanıcıyı index1.php sayfasına yönlendir
        header("Location: index1.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($baglan);
    }

    mysqli_close($baglan);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        a {
            margin: 5px;
            padding: 5px 10px;
        }
    </style>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
    <div class="container mt-3">
        <form name="guest" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			
			 <input type="submit" class="btn btn-primary" value="Submit" /> 
             <a href="./index1.php"<button type="button" class="btn btn-primary"> index </button></a><br>
            
	        <textarea name="thema" rows="1" cols="100"></textarea><br/><br>
            <textarea name="message" rows="10" cols="100"></textarea><br/>
           
           
        </form>
    </div>
</body>
</html>
