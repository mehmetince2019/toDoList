<?php


error_reporting(0);
$host 	= 'localhost'; //host bilgisi
$user 	= 'userxxx'; //kullanıcı adı
$pass 	= 'xxx'; //sifre
$db	= 'td_xxx'; //veritabanı ismi

$table  = 'todo';
			
$baglan = mysqli_connect($host, $user, $pass, $db) or die (mysqli_Error());
mysqli_query($baglan,"SET CHARACTER SET 'utf8'");
mysqli_query($baglan,"SET NAMES 'utf8'");

?>