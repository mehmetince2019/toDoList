<?php
session_start();

// Oturum kontrolü
if (!isset($_SESSION['username'])) {
    // Kullanıcı oturumu yok, giriş sayfasına yönlendir
    header("Location: index.php");
    exit();
}

// Çıkış işlemi
if (isset($_GET['logout'])) {
    // Oturumu kapat
    session_destroy();

    // Remember Me seçeneği işaretlendi mi?
    if (isset($_COOKIE['session_key'])) {
        $session_key = $_COOKIE['session_key'];

        // Oturum anahtarını veritabanından sil
        $sql = "DELETE FROM sessions WHERE session_key = '$session_key'";
        $conn->query($sql);

        // Oturum anahtarını cookie'den sil
        setcookie('session_key', '', time() - 3600, '/');
    }

    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body, html {
            padding: 3px 3px 3px 3px;
            background-color: #D8DBE2;
            font-family: Verdana, sans-serif;
            font-size: 10pt;
            text-align: center;
        }

        a {
            margin: 5px;
            padding: 5px 10px;
        }

        p.solid {border-style: solid;}

        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }

        div.main_page {
            position: relative;
            display: table;
            width: 800px;
            margin-bottom: 3px;
            margin-left: auto;
            margin-right: auto;
            padding: 0px 0px 0px 0px;
            border-width: 2px;
            border-color: #212738;
            border-style: solid;
            background-color: #FFFFFF;
            text-align: left;
        }
    </style>

    <title>Spaeter Page</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>

<div class="main_page">

    <div class="container mt-3">

        <a href="index1.php"><button type="button" class="btn btn-primary"> Index </button></a>
        <a href="ekle_madde_index.php"><button type="button" class="btn btn-primary"> Ekle </button></a>

        <?php
        error_reporting(0);
        include_once 'datab.php';

        $sayfa = $_GET['sayfa'] ? $_GET['sayfa'] : 1;
        $toplam_icerik_sayisi = mysqli_num_rows(mysqli_query($baglan, 'SELECT id FROM todo_spaeter'));
        $limit = 130;
        $sonSayfa = ceil($toplam_icerik_sayisi / $limit);
        $baslangic = ($sayfa - 1) * $limit;

        if ($sonSayfa >= $sayfa) {
            $icerik_sorgu = mysqli_query($baglan, 'SELECT * FROM todo_spaeter ORDER BY id DESC LIMIT ' . $baslangic . ',' . $limit);

        echo '<table class="table table-bordered">';

echo'<table style="width:100%">';	
			
           
            echo '<tbody>';

            while ($icerik = mysqli_fetch_assoc($icerik_sorgu)) {
                echo '<tr>';
                echo '<td>' . $icerik['thema'] . '</td>';
                echo '<td><a href="speater_ayrinti.php?id=' . $icerik['id'] . '" class="btn btn-outline-primary btn-sm">Detail</a></td>';
                echo '<td><a href="spaeterden_geri_yolla.php?id=' . $icerik['id'] . '" class="btn btn-outline-dark btn-sm">Zurück</a></td>';
				
		echo'<td>';				
echo '<a href="spaterden_done_yolla.php?id=' . $icerik['id'] . '"><button type="button" class="btn btn-outline-dark btn-sm">Done</button></a>';
echo'</td>';	
				
                echo '<td><a href="spaeter_update.php?id=' . $icerik['id'] . '" class="btn btn-outline-success btn-sm">Edit</a></td>';
                echo '<td><a href="spaeter_delete.php?id=' . $icerik['id'] . '" class="btn btn-outline-danger btn-sm">DEL</a></td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
        } else {
            echo '<p class="solid">No data found</p>';
        }
        ?>
    </div>
</div>

</body>
</html>
