<?php
include_once("datab.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Silme işlemini onayladıktan sonra veritabanından kaydı sil
    $query = "DELETE FROM todo_spaeter WHERE id = $id"; // todo_spaeter tablosunda silme işlemi yapılıyor
    $result = mysqli_query($baglan, $query);

    if ($result) {
        header("Location: https://ince.one/td/spaeter.php");
    } else {
        echo "Kayıt silinirken bir hata oluştu.";
    }
} else {
    echo "Geçersiz işlem.";
}
?>
