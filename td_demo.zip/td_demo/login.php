<?php
session_start();

// Veritabanı bağlantısı için gerekli bilgiler
$servername = "localhost";
$username = "td_userxxx";
$password = "Pass_xxx";
$dbname = "td_db_xxx";



// Veritabanına bağlanma
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol etme
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// Kullanıcı girişini kontrol etme
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Kullanıcı adı ve parolayı alırken htmlspecialchars ve trim fonksiyonlarını kullanarak güvenli hale getiriyoruz
    $username = htmlspecialchars(trim($_POST['username']));
    $password = htmlspecialchars(trim($_POST['password']));

    // Kullanıcı adı ve parolayı veritabanında kontrol etme
    $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
    
    // Prepared statement oluştur
    $stmt = $conn->prepare($sql);
    
    // Parametreleri bağla
    $stmt->bind_param("ss", $username, $password);
    
    // Sorguyu çalıştır
    $stmt->execute();

    // Sonuçları al
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // Kullanıcı doğru giriş yaptı, oturumu oluştur
        $_SESSION['username'] = $username;

        // Remember Me seçeneği işaretlendi mi?
        if (isset($_POST['remember'])) {
            // Oturum anahtarını oluştur
            $session_key = bin2hex(random_bytes(16));

            // Oturum anahtarını veritabanına kaydet
            $sql = "INSERT INTO sessions (username, session_key) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $username, $session_key);
            $stmt->execute();

            // Oturum anahtarını kullanıcıya bir cookie olarak gönder
            setcookie('session_key', $session_key, time() + 604800, '/');
        }

        header("Location: index1.php");
        exit();
    } else {
        // Giriş başarısız, hata mesajı göster
        echo "Geçersiz kullanıcı adı veya parola.";
    }

    // Prepared statement'i kapat
    $stmt->close();
}

// Veritabanı bağlantısını kapatma
$conn->close();
?>
