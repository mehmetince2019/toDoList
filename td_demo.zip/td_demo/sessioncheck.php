<?php
session_start();

// Oturum kontrolü
if (isset($_SESSION['username'])) {
    // Kullanıcı oturumu varsa, index1.php'ye yönlendir
    header("Location: index1.php");
    exit();
}

// Çıkış işlemi
if (isset($_GET['logout'])) {
    // Oturumu kapat
    session_destroy();

    // Remember Me seçeneği işaretlendi mi?
    if (isset($_COOKIE['session_key'])) {
        $session_key = $_COOKIE['session_key'];

        // Veritabanından oturum anahtarını silmek için bağlantıyı açın
        // $conn = new mysqli("localhost", "kullanici_adi", "parola", "veritabani_adi");

        // Veritabanında oturumu silme işlemi
        // Örneğin:
        // $sql = "DELETE FROM sessions WHERE session_key = '$session_key'";
        // $conn->query($sql);

        // Veritabanı işlemleri tamamlandıktan sonra oturum anahtarını cookie'den sil
        setcookie('session_key', '', time() - 3600, '/');
    }

    // Çıkış işlemi tamamlandıktan sonra giriş sayfasına yönlendir
    header("Location: index.php");
    exit();
}
?>
