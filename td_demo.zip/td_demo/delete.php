<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Silme İşlemi</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
		
		echo "<div class='container text-center'>";
        echo "<p class='mt-4'>Kaydı silmek istediğinize emin misiniz?</p>";
		
		echo "<a href='delete2.php?id=$id' class='btn btn-danger m-2'>Evet</a>";
        echo "<a href='index.php' class='btn btn-primary m-2'>Hayır</a>";
		
		echo "</div>";
    } else {
        echo "Geçersiz işlem.";
    }
    ?>
</body>
</html>
