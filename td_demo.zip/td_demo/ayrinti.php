<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        a {
            margin: 5px;
            padding: 5px 10px;
        }

        p.solid {
            border-style: solid;
        }
    </style>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>

<body>
    <div class="container mt-3">
        <?php
        // include database connection file
        include_once("datab.php");

        // Check if form is submitted for user update, then redirect to homepage after update
        if(isset($_POST['update']))
        {   
            $id = $_POST['id'];
            $thema = $_POST['thema'];
            $message = $_POST['message'];

            // update user data
            $result = mysqli_query($baglan, "UPDATE todo SET thema='$thema',message='$message' WHERE id=$id");

            // Redirect to homepage to display updated user in list
            header("Location: index1.php");
        }

        // Display selected user data based on id
        // Getting id from url
        $id = $_GET['id'];

        // Fetch user data based on id
        $result = mysqli_query($baglan, "SELECT * FROM todo WHERE id=$id");

        while($user_data = mysqli_fetch_array($result))
        {
            $thema = $user_data['thema'];
            $message = $user_data['message'];

            // Check if the message contains links starting with http or www
            $pattern = '/((http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/|www\.)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?)/i';
            if (preg_match($pattern, $message)) {
                // If links exist, replace them with <a> tags with target="_blank"
                $message = preg_replace_callback($pattern, function ($matches) {
                    $link = $matches[1];
                    // Check if the link starts with http or www
                    if (preg_match('/^(http:\/\/|https:\/\/)/i', $link)) {
                        return '<a href="' . $link . '" target="_blank">' . $link . '</a>';
                    } else if (preg_match('/^www\./i', $link)) {
                        return '<a href="http://' . $link . '" target="_blank">' . $link . '</a>';
                    } else {
                        return $link;
                    }
                }, $message);
            }
        }
        ?>

        <title>Edit User Data</title>
        <body>
            <a href="index1.php" class="btn btn-primary">Home</a>
            <br><br>

            <table border="0">
                <tr>
                    <td><?php echo $thema; ?></td>
                </tr>
                <tr>
                    <td><?php echo nl2br($message); ?></td>
                </tr>
                <tr>
                  <td><?php #echo $_GET['id']; ?></td>
                </tr>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <td>
                                    <?php
                                        // Fetching the previous record's ID
                                        $prevResult = mysqli_query($baglan, "SELECT id FROM todo WHERE id < $id ORDER BY id DESC LIMIT 1");
                                        $prevRecord = mysqli_fetch_array($prevResult);
                                        $prevId = $prevRecord['id'];

                                        if ($prevId) {
                                            echo '<a href="ayrinti.php?id=' . $prevId . '" class="btn btn-warning">  <<<  </a>';
                                        }
                                    ?>
                                </td>
                                <td>
                                    <a href="update.php?id=<?php echo $id; ?>" class="btn btn-primary">Edit</a>
                                </td>
                                <td>
                                    <a href="spaetera_send.php?id=<?php echo $id; ?>" class="btn btn-primary">Spaeter</a>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $id; ?>" class="btn btn-danger">Delete</a>
                                </td>
                                <td>
                                    <?php
                                        // Fetching the next record's ID
                                        $nextResult = mysqli_query($baglan, "SELECT id FROM todo WHERE id > $id ORDER BY id ASC LIMIT 1");
                                        $nextRecord = mysqli_fetch_array($nextResult);
                                        $nextId = $nextRecord['id'];

                                        if ($nextId) {
                                            echo '<a href="ayrinti.php?id=' . $nextId . '" class="btn btn-success float-end"> >>> </a>';
                                        }
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
    </html>
