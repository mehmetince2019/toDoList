<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
<style>
	a {
		margin: 5px;
		padding: 5px 10px;
	}
	p.solid {
		border-style: solid;
	}
</style>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
<div class="container mt-3">
	<?php
		// include database connection file
		include_once("datab.php");

		// Check if form is submitted for user update, then redirect to detail page after update
		if(isset($_POST['update']))
		{
			$id = $_POST['id'];
			$thema = $_POST['thema'];
			$message = $_POST['message'];

			// update user data
			$result = mysqli_query($baglan, "UPDATE todo_spaeter SET thema='$thema',message='$message' WHERE id=$id");

			// Redirect to detail page to display updated user data
			header("Location: spaeter.php?id=".$id);
		}

		// Display selected user data based on id
		// Getting id from url
		$id = $_GET['id'];

		// Fetch user data based on id
		$result = mysqli_query($baglan, "SELECT * FROM todo_spaeter WHERE id=$id");

		while($user_data = mysqli_fetch_array($result))
		{
			$thema = $user_data['thema'];
			$message = $user_data['message'];
		}
	?>
	<title>Edit User Data</title>
	<body>
							<a href="index1.php" class="btn btn-primary">Index</a> <br/>
	
		<form name="update_user" method="post" action="spaeter_update.php">
			<table border="0">
				<tr>
					<td><textarea name="thema" class="form-control" cols="150" rows="1"><?php echo $thema;?></textarea></td>
				</tr>
				<tr>
					<td><textarea name="message" class="form-control" cols="150" rows="20"><?php echo $message;?></textarea></td>
				</tr>
				<tr>
					<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				</tr>
				<tr>
					<td><input type="submit" name="update" value="Update" class="btn btn-primary"></td>
				</tr>
				
			</table>
		</form>
	</body>
</html>
