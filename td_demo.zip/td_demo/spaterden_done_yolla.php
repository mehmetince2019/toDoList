<?php
error_reporting(0);

include_once 'datab.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch data from todo table based on the provided ID
    $fetch_query = "SELECT * FROM todo_spaeter WHERE id = $id";
    $result = mysqli_query($baglan, $fetch_query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        // Insert data into todo_done table
        $insert_query = "INSERT INTO todo_done (id, thema, message) VALUES (
            '{$row['id']}',
            '{$row['thema']}',
            '{$row['message']}'
        )";

        $insert_result = mysqli_query($baglan, $insert_query);

        if ($insert_result) {
            // Optionally, delete the entry from todo table
            $delete_query = "DELETE FROM todo_spaeter WHERE id = $id";
            mysqli_query($baglan, $delete_query);

            echo "Data moved successfully.";
            header("Location: spaeter.php"); // Redirect back to index.php
            exit(); // Ensure that no further code is executed after the redirect
        } else {
            echo "Error moving data to todo_done table: " . mysqli_error($baglan);
        }
    } else {
        echo "Error fetching data from todo table: " . mysqli_error($baglan);
    }
} else {
    echo "Invalid request. Missing or empty 'id' parameter.";
}

// You might want to redirect the user back to index.php or any other page after the process.
// header("Location: index1.php");
?>
