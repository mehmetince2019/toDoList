<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "ID: " . $id . "<br>";
echo "Table: " . $table . "<br>";



# error_reporting(0);

$host 	= 'localhost'; //host bilgisi
$user 	= 'td_user_xxx'; //kullanıcı adı
$pass 	= 'Pass_xxx'; //sifre
$db	= 'db_xxx'; //veritabanı ismi

$table  = 'todo_spaeter';
			
$baglan = mysqli_connect($host, $user, $pass, $db) or die (mysqli_Error());
mysqli_query($baglan,"SET CHARACTER SET 'utf8'");
mysqli_query($baglan,"SET NAMES 'utf8'");

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch data from todo table based on the provided ID
    $fetch_query = "SELECT * FROM todo WHERE id = $id";
    $result = mysqli_query($baglan, $fetch_query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        // Insert data into todo_spaeter table
        $insert_query = "INSERT INTO todo_spaeter (id, thema, message) VALUES (
            '{$row['id']}',
            '{$row['thema']}',
            '{$row['message']}'
        )";

        $insert_result = mysqli_query($baglan, $insert_query);

        if ($insert_result) {
            // Optionally, delete the entry from todo table
            $delete_query = "DELETE FROM todo WHERE id = $id";
            mysqli_query($baglan, $delete_query);

            echo "Data moved successfully.";
            header("Location: index1.php"); // Redirect back to index.php
            exit(); // Ensure that no further code is executed after the redirect
        } else {
            echo "Error moving data to todo_spaeter table: " . mysqli_error($baglan);
        }
    } else {
        echo "Error fetching data from todo table: " . mysqli_error($baglan);
    }
} else {
    echo "Invalid request. Missing or empty 'id' parameter.";
}
?>
