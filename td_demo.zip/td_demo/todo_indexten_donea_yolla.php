<?php
error_reporting(E_ALL);

include_once 'datab.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];

    // Use prepared statements to prevent SQL injection
    $fetch_query = "SELECT * FROM todo WHERE id = ?";
    $stmt = mysqli_prepare($baglan, $fetch_query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        // Insert data into todo_done table using prepared statement
        $insert_query = "INSERT INTO todo_done (id, thema, message) VALUES (?, ?, ?)";
        $insert_stmt = mysqli_prepare($baglan, $insert_query);
        mysqli_stmt_bind_param($insert_stmt, "iss", $row['id'], $row['thema'], $row['message']);
        $insert_result = mysqli_stmt_execute($insert_stmt);

        if ($insert_result) {
            // Optionally, delete the entry from todo table
            $delete_query = "DELETE FROM todo WHERE id = ?";
            $delete_stmt = mysqli_prepare($baglan, $delete_query);
            mysqli_stmt_bind_param($delete_stmt, "i", $id);
            mysqli_stmt_execute($delete_stmt);

            echo "Data moved successfully.";
            header("Location: index1.php");
            exit();
        } else {
            echo "Error moving data to todo_done table: " . mysqli_error($baglan);
        }
    } else {
        echo "Error fetching data from todo table: " . mysqli_error($baglan);
    }
} else {
    echo "Invalid request. Missing or empty 'id' parameter.";
}
?>
