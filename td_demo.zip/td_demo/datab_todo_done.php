<?php


error_reporting(0);
$host 	= 'localhost'; //host bilgisi
$user 	= 'user_xxx'; //kullanıcı adı
$pass 	= 'pass-xxx'; //sifre
$db	= 'td_db_xxx'; //veritabanı ismi

$table  = 'todo_done';
			
$baglan = mysqli_connect($host, $user, $pass, $db) or die (mysqli_Error());
mysqli_query($baglan,"SET CHARACTER SET 'utf8'");
mysqli_query($baglan,"SET NAMES 'utf8'");

?>