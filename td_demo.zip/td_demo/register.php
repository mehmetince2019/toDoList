<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Üye Kaydı</title>
    <style>
        .register {
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            background: #f3f3f3;
        }
        .register h6 {
            text-align: center;
        }
        .register label {
            display: inline-block;
            margin-bottom: 5px;
        }
        .register input[type="text"],
        .register input[type="password"],
        .register input[type="email"] {
            width: 100%;
            padding: 5px;
        }
        .register input[type="submit"] {
            width: 100%;
            padding: 7px;
            background: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="register">
        <h6>Üye Kaydı</h6>
        <form action="register_process.php" method="post">
            <label for="username">Kullanıcı Adı:</label>
            <input type="text" name="username" id="username" required><br>
            <label for="password">Parola:</label>
            <input type="password" name="password" id="password" required><br>
            <label for="email">E-posta:</label>
            <input type="email" name="email" id="email" required><br>
            <input type="submit" value="Kayıt Ol">
        </form>
    </div>
</body>
</html>
