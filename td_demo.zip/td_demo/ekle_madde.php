<?php
// include database connection file
include_once("datab.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $thema = $_POST['thema'];
    $message = $_POST['message'];

    // Veritabanı sorgusunu hazırla
    $stmt = $baglan->prepare("INSERT INTO todo (thema, message) VALUES (?, ?)");
    $stmt->bind_param("ss", $thema, $message);

    if ($stmt->execute()) {
        echo "Veri eklendi. <br>";

        // Veri ekledikten sonra kullanıcıyı index1.php sayfasına yönlendir
        header("Location: index1.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$baglan->close();
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Gerekli CSS ve JS bağlantıları buraya ekleyebilirsiniz -->
</head>
<body>
    <div class="container mt-3">
        <a href="index1.php">Home</a>
        <br/><br/>

        <form name="guest" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <textarea name="thema" rows="2" cols="80"></textarea><br/><br>
            <textarea name="message" rows="20" cols="100"></textarea><br/>

            <input type="submit" class="btn btn-primary btn-lg" value="Submit" />
        </form>
    </div>
</body>
</html>
