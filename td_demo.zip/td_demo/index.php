


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        .login {
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            background: #f3f3f3;
        }
        .login h6 {
            text-align: center;
        }
        .login label {
            display: inline-block;
            margin-bottom: 5px;
        }
        .login input[type="text"],
        .login input[type="password"] {
            width: 100%;
            padding: 5px;
        }
        .login input[type="submit"] {
            width: 100%;
            padding: 7px;
            background: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="login">
        <h6>Login</h6>
        <form action="login.php" method="post">
            <label for="username">
                <i class="fas fa-user"></i> Username
            </label>
            <input type="text" name="username" id="username" required><br>
            <label for="password">
                <i class="fas fa-lock"></i> Password
            </label>
            <input type="password" name="password" id="password" required><br>
            <br><br>
               
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
