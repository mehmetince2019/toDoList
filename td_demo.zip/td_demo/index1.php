
<?php
session_start();

// Oturum kontrolü
if (!isset($_SESSION['username'])) {
    // Kullanıcı oturumu yok, giriş sayfasına yönlendir
    header("Location: index.php");
    exit();
}

// Çıkış işlemi
if (isset($_GET['logout'])) {
    // Oturumu kapat
    session_destroy();

    // Remember Me seçeneği işaretlendi mi?
    if (isset($_COOKIE['session_key'])) {
        $session_key = $_COOKIE['session_key'];

        // Oturum anahtarını veritabanından sil
        $sql = "DELETE FROM sessions WHERE session_key = '$session_key'";
        $conn->query($sql);

        // Oturum anahtarını cookie'den sil
        setcookie('session_key', '', time() - 3600, '/');
    }

    header("Location: index.php");
    exit();
}
?>

<!--table name degistir 
--!>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
	
	
	

<style>
	
	 body, html {
    padding: 3px 3px 3px 3px;

    background-color: #D8DBE2;

    font-family: Verdana, sans-serif;
    font-size: 10pt;
    text-align: left;
  }

	
	a{
		margin:5px;
		padding:5px 10px;
	}
	
	
	p.solid {border-style: solid;}
	
	table, th, td {
  border:1px solid black;
  border-collapse: collapse;
}

 div.main_page {
    position: relative;
    display: table;

    width: 900px;

    margin-bottom: 3px;
    margin-left: auto;
    margin-right: auto;
    padding: 0px 0px 0px 0px;

    border-width: 2px;
    border-color: #212738;
    border-style: solid;

    background-color: #FFFFFF;

    text-align: left;	
	
	
</style>


<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>

 <div class="main_page">	
	
<div class="container mt-3">	
	



	
<a href="ekle_madde_index.php"<button type="button" class="btn btn-primary"> Ekle </button></a>	
<!--<a href="./index.php"<button type="button" class="btn btn-primary"> index </button></a>	--!>

 <a href="spaeter.php"<button type="button" class="btn btn-primary"> SPÄTER index </button></a>
 <a href="todo_done.php"<button type="button" class="btn btn-primary"> done index </button></a>

 <a href="index1.php?logout=1"<button type="button" class="btn btn-primary"> Logout</button></a>


<br>


 
<?php

include_once '../menu_icerdeki_ust.php';



error_reporting(0);


include_once 'datab.php';




	$sayfa = $_GET['sayfa'] ? $_GET['sayfa'] : 1; //urlden gelen sayfa değeri var ise o değeri, yok ise 1 değeri veriyoruz.
	$toplam_icerik_sayisi = mysqli_num_rows(mysqli_query($baglan,'SELECT id FROM todo'));
	$limit = 130; //sayfalamada her sayfada gösterilecek veri sayısı
	$sonSayfa = ceil($toplam_icerik_sayisi/$limit);//içerik sayısı ile limit değeri bölünüyor ve çıkan değer yuvarlanıyor. böylece sayfa sayısı diğer bir ifadeyse sonm sayfa değeri bulunuyor
	//mesela 22 veri var. biz 4 er 4er listeliyoruz. 22 veriyi 6 sayfada gösterebiliriz. 
	//22/4 = 5.5 sonucunu yukarı yuvarlayıp sayfa sayısını buluyoruz.
	$baslangic = ($sayfa-1)*$limit;
	/*
		mesela ilk sayfa 1. sayfa gösterilecek ise 1-1 = 0 - 0*4=0, veritabanından 0.veriden itibaren veriler getirilmeye başlansın
		2. sayfa gösterilecek ise 2-1 = 1 - 1*4=4, veritabanından 4. veriden itibaren veriler getirilmeye başlansın
	*/
	
	if($sonSayfa >= $sayfa){
		
		$icerik_sorgu = mysqli_query($baglan,'SELECT * FROM todo ORDER BY id DESC LIMIT '.$baslangic.','.$limit ); //başlangıç değerinden itibaren kaç tane veri getirilecek ise veritabanından LIMIT komutu ile verileri çekiyoruz
		

	
	echo'<table style="width:100%">';		
	
		while ($icerik = mysqli_fetch_assoc($icerik_sorgu)){ //çekilen veriler içerisinde dönüyoruz, teker teker veriyi $icerik değişkenine aktarıyoruz 
	
			
					
	echo'<tr>';	
		
    echo'<td>';	
			
	
			
	echo  $icerik['thema'] ; //ve veri değerlerini yazdırıyoruz
	
	echo'</td>';	
	

	
			
			
echo'<td>';	
	echo '<a href="ayrinti.php?id='.$icerik['id'].'"<button type="button" class="btn btn-outline-primary btn-sm">Detail </button></a>';		
echo'</td>';				
	
echo'<td>';	
//echo '<a href="ayrinti.php?id='.$icerik['id'].'"<button type="button" class="btn btn-outline-primary btn-sm">Det </button></a>';
			
//echo '<a href="update.php?id='.$icerik['id'].'"<button type="button" class="btn btn-outline-warning btn-sm">Edit </button></a>';

echo '<a href="update.php?id='.$icerik['id'].'"<button type="button" class="btn btn-outline-success btn-sm">Edit </button></a>';
			
			
			
echo'</td>';				
echo'<td>';				
echo '<a href="todo_indexten_donea_yolla.php?id=' . $icerik['id'] . '"><button type="button" class="btn btn-outline-dark btn-sm">Done</button></a>';
echo'</td>';	
			
echo'<td>';		
echo '<a href="spaetera_send.php?id=' . $icerik['id'] . '"><button type="button" class="btn btn-outline-dark btn-sm">später</button></a>';
echo'</td>';			
			
echo'<td>';	
echo '<a href="delete.php?id='.$icerik['id'].'"<button type="button" class="btn btn-outline-danger btn-sm">Dl </button></a>';				
echo'</td>';		
			
		}	echo'</td>';
		/*sayfalama buton kodları*/
		if($toplam_icerik_sayisi > $limit){	//içerik sayısı, her sayfada gösterilecek içerik sayısından büyük ise sayfalama butonları aktif edilsin	 
			echo '<br><br>';
			/*
				$x = 2 olduğu durumda, aktif sayfanın önceki ve sonraki 2 sayfa gösterilir, sonrasına ... ifadesi konularak kısaltma yapılır. 
				böylelikle bütün sayfaları yazmamıza gerek kalmaz.
				örnekler:
				« Önceki 1...4 5 [6] 7 8...11 Sonraki »	  ||  [1] 2 3...11 Sonraki »	  ||   « Önceki 1...9 10 [11] 
			*/
			$x = 2; //kısaltma limiti 
			if($sayfa > 1){	//sayfa 1 den küçük ise [Önceki] butonu oluşturulmaya uygundur	
				$onceki = $sayfa-1;	//aktif sayfanın bir önceki sayfa bulunur		
				
				echo'<p class="solid"><td>';
				
				echo '<a href="?sayfa='.$onceki.'"> <button type="button" class="btn btn-primary btn-lg"> << </button> </a>'; //link içerisine yazdırılıp [Önceki] butonu oluşturulur	  
				
				
			}	
		
			echo '<a href="index.php"<button type="button" class="btn btn-primary btn-lg btn-block"> index </button></a>'; 
			
			
			
			
		
			
				
			
				
			if($sayfa==1){ //sayfalamada 1. sayfada bulunuyorsak
				echo '<a>[1]</a>'; //1. sayfayı menüde aktif olarak gösteriyoruz
			}
			else{ // bulunmuyorsak
				echo '<a href="?sayfa=1">1</a>'; //normal olarak gözüksün, aktif olmasın	
			}
			//menü kısaltma işlemi
				//bulunduğumuz sayfa yani $sayfa = 6 olduğu durumda
			if($sayfa-$x > 2){ //6-2 > 2 değeri true döndürecek
				echo '...'; //kısaltma etiketi yazdırılacak	
				$i = $sayfa-$x; //$i değişkenine 4 değeri atanacak..*** altta 2 yaziliydi***	 
			}else { 			
				$i = 226; 		  
			}
			//$sayfa = 6 olduğu durumda = sonuc çıktısı -> 1 ...
			
			for($i; $i<=$sayfa+$x; $i++) { //$i yani 4 değeri 8 değerine ulaşasıya kadar döngü çalışsın	> 4  5  6  7  8	
				if($i==$sayfa){ //$i değeri bulunduğumuz sayfa ile eşitse
					echo '&nbsp;<a>['.$i.']</a>&nbsp;'; // aktif olarak işaretlensin ve yazdırılsın > 4  5  [6]  7  8	
				}
				else{//değil ise
					echo '<a href="?sayfa='.$i.'">'.$i.'</a>'; //normal olarak yazdırılsın
				}
				if($i==$sonSayfa) break;  }
			
			//$sayfa = 6 olduğu durumda = sonuc çıktısı -> 1 ... 4  5  [6]  7  8	
			
			if($sayfa+$x < $sonSayfa-1) { //6+2<11-1 ise	
				echo '...'; //kısaltma etiketi yazdırılacak				
				echo '<a href="?sayfa='.$sonSayfa.'">'.$sonSayfa.'</a>'; //	son sayfa yazdırılacak	  
			}elseif($sayfa+$x == $sonSayfa-1) { 			
				echo '<a href="?sayfa='.$sonSayfa.'">'.$sonSayfa.'</a>'; 		 
			}
			//$sayfa = 6 olduğu durumda = sonuc çıktısı -> 1 ... 4  5  [6]  7  8 ... 11	
			//menü kısaltma işlemi
			
			if($sayfa < $sonSayfa){	//bulunduğumuz sayfa hala son sayfa değil ise	  
				$sonraki = $sayfa+1; //bulundğumuz sayfa değeri 1 arttırılıyor	
				
				
				
			
				
			
			
				
	echo '<a href="?sayfa='.$sonraki.'"<button type="button" class="btn btn-primary btn-lg btn-block"> >> </button></a>'; //ve Sonraki butonu oluşturulup yazdırılıyor 		  
				
			
				
			}	
		}
		/*sayfalama buton kodları*/
	}else{
		echo 'Hiç içerik yok';
		header("Location:index1.php");
	}	
	
			
			
	
			
			
?>	
	

	</div>		
			
	</div>	
	
	

	
	</body>
	
	</html>